# OmniCalc™ Android & Google Play Store Package
**Author & Publisher:** Sushant Mishra <sushantmishra20006@gmail.com>
**Package Name:** `app.omnicalc.compliance`
**Live Web Application:** https://ais-pre-i7h4zglp4fxrnsrivhvjud-125329514266.asia-east1.run.app

This directory contains the complete, production-ready Android Studio project and Google Play Store distribution assets for **OmniCalc™ Compliance Suite**.

---

## 🚀 Quick Publication Options

### Option 1: 1-Click Instant AAB via PWABuilder (No Android Studio needed)
1. Go to **https://www.pwabuilder.com?url=https%3A%2F%2Fais-pre-i7h4zglp4fxrnsrivhvjud-125329514266.asia-east1.run.app**
2. The site automatically detects the verified Web App Manifest, Service Worker, and 512x512 icons.
3. Click **"Package for Stores"** -> Select **"Google Play"**.
4. Set Package ID to `app.omnicalc.compliance`.
5. Click **"Generate"** to download the signed `app-release.aab`.
6. Upload that `.aab` directly into **[Google Play Console](https://play.google.com/console)**!

---

### Option 2: Build with Android Studio (Full Native Control)
1. Open Android Studio.
2. Select **File -> Open...** and choose this extracted folder.
3. Wait for Gradle sync to complete.
4. Go to **Build -> Generate Signed Bundle / APK...**
5. Select **Android App Bundle (.aab)**.
6. Create or select your keystore and click **Create**.
7. Your generated `.aab` will be in `app/release/app-release.aab`.
8. Upload this file to Google Play Console under **Production -> Create new release**.

---

## 📱 What is in this package?
- `app/`: Complete Android source code with Trusted Web Activity (TWA) and offline fallbacks.
- `store-assets/`: Play Store App Icon (512x512), Feature Graphic (1024x500), and store listing texts.
- `build.gradle` & `settings.gradle`: Production Gradle build configuration.
- `STORE_LISTING.txt`: Copy-paste titles, descriptions, and compliance certifications.
